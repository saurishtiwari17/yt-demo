# YouTube Video Generator — DEMO (No API Keys Needed)

This is a **local-only demo** of the video generation pipeline.
It does NOT upload anything and does NOT need any API keys or internet.

## What it does
1. Reads a topic from `topics/topics.txt`
2. Generates a simple script from a built-in template (no LLM)
3. Creates a voiceover using **pyttsx3** (free offline TTS) — or silent audio if not installed
4. Generates colourful placeholder slide images locally with **Pillow** (no Pexels)
5. Assembles images + audio into an MP4 using **FFmpeg**
6. Saves the video to the `output/` folder — that's it, no upload

## Requirements
- Python 3.10+
- FFmpeg installed and in PATH
- Python packages: `pip install Pillow pyttsx3`
  - `Pillow` — image generation (required)
  - `pyttsx3` — offline voiceover (optional; falls back to silent audio)

### Installing FFmpeg
- Ubuntu/Debian: `sudo apt install ffmpeg`
- Mac: `brew install ffmpeg`
- Windows: download from ffmpeg.org and add to PATH

### Installing pyttsx3 voice support
- Windows: works out of the box (uses SAPI5)
- Mac: works out of the box (uses NSSpeechSynthesizer)
- Linux: also install espeak → `sudo apt install espeak`

## How to run
```bash
pip install Pillow pyttsx3
python demo.py
```

Optional flags:
```bash
python demo.py --topic "Why humans fear the dark"   # use a specific topic
python demo.py --slides 6                            # number of slides
python demo.py --no-voice                            # silent video, faster
```

The finished video appears in `output/` as `demo_video.mp4`.

## Folder structure
```
yt_demo/
├── demo.py                  ← run this
├── topics/topics.txt        ← your topics, one per line
├── modules/
│   ├── script_writer.py     ← template-based script (no AI)
│   ├── voiceover.py         ← offline TTS / silent fallback
│   ├── slide_maker.py       ← Pillow placeholder images
│   └── video_assembler.py   ← FFmpeg assembly
└── output/                  ← finished video goes here
```

When you're happy with the output quality, you can swap each demo module
for the real API-powered version (LLM script, ElevenLabs voice, Pexels images).

---

## Adding ElevenLabs voice (optional, much better quality)

ElevenLabs gives natural human-sounding voices instead of robotic espeak.
It needs an API key and costs per character, but has a free tier (~10,000 chars/month).

### Setup
1. Sign up at https://elevenlabs.io and copy your API key
2. Install the SDK:
   ```bash
   pip install elevenlabs
   ```
3. Provide your key in ONE of two ways:

   **Option A — environment variable (recommended):**
   ```bash
   export ELEVENLABS_API_KEY="your-key-here"     # Mac/Linux
   set ELEVENLABS_API_KEY=your-key-here          # Windows
   python demo.py
   ```

   **Option B — command line flag:**
   ```bash
   python demo.py --elevenlabs-key YOUR_KEY_HERE
   ```

### Choosing a voice
Default voice is "Adam" (deep male). To use another:
1. Browse voices at https://elevenlabs.io/voice-library
2. Copy the voice ID
3. Pass it:
   ```bash
   python demo.py --elevenlabs-voice VOICE_ID_HERE
   # or set ELEVENLABS_VOICE_ID env var
   ```

### How fallback works
The voiceover engine tries in this order and uses the first that produces real audio:
1. ElevenLabs (if key set + SDK installed)
2. espeak (Linux offline)
3. pyttsx3 (cross-platform offline)
4. macOS `say`
5. gTTS (free, needs internet)
6. silent audio (last resort)

So if your ElevenLabs key is missing, wrong, or out of quota, the demo
automatically falls back to a free engine instead of crashing. Watch the
terminal: `✅ Voiceover created with ElevenLabs` confirms it used ElevenLabs.

### Cost note
At ~3,200 characters per 5-minute script, the ElevenLabs free tier (~10,000
chars/month) covers about 3 test videos. The $5/mo Starter tier covers ~9,
and the $11/mo Creator tier covers ~31.
