"""
modules/voiceover.py  (DEMO version — ElevenLabs + offline fallbacks)
──────────────────────────────────────────────────────────────────────
Generates a voiceover. Tries engines in priority order and VERIFIES
the output actually contains audio before accepting it.

Engine priority:
    1. ElevenLabs        (BEST quality — needs API key, costs per char)
    2. espeak / espeak-ng (Linux offline — reliable, robotic)
    3. pyttsx3            (cross-platform offline — flaky on Linux)
    4. say command        (macOS built-in)
    5. gTTS               (free, decent, needs internet, no key)
    6. silent audio       (final fallback so the video still builds)

ElevenLabs setup:
    1. Get a free/paid key at elevenlabs.io
    2. Set it via environment variable (recommended):
         export ELEVENLABS_API_KEY="your-key-here"      # Mac/Linux
         set ELEVENLABS_API_KEY=your-key-here           # Windows
       OR pass it on the command line:  python demo.py --elevenlabs-key YOUR_KEY
    3. pip install elevenlabs
"""

import os
import logging
import shutil
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

MIN_VALID_BYTES = 8000

# ── ElevenLabs config (can be overridden by demo.py) ─────────────────────
ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY", "")
# "Adam" — deep, natural male voice. Browse more at elevenlabs.io/voice-library
ELEVENLABS_VOICE_ID = os.getenv("ELEVENLABS_VOICE_ID", "pNInz6obpgDQGcFmaJgB")
ELEVENLABS_MODEL = "eleven_turbo_v2"   # turbo = cheapest + fast; eleven_multilingual_v2 = higher quality


def set_elevenlabs_key(key: str, voice_id: str = None):
    """Allow demo.py to inject the key/voice at runtime (from a CLI flag)."""
    global ELEVENLABS_API_KEY, ELEVENLABS_VOICE_ID
    if key:
        ELEVENLABS_API_KEY = key
    if voice_id:
        ELEVENLABS_VOICE_ID = voice_id


def generate_voiceover(text: str, output_dir: Path, use_voice: bool = True) -> tuple[Path, float]:
    """
    Convert text to speech, trying ElevenLabs first then offline fallbacks.

    Returns:
        (audio_path, duration_seconds)
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    wav_path = output_dir / "voiceover.wav"

    word_count = len(text.split())
    estimated = max(8.0, word_count / 2.5)

    if not use_voice:
        logger.info("🔇 --no-voice flag set, generating silent audio")
        _silent_audio(wav_path, estimated)
        return wav_path, _duration(wav_path) or estimated

    # Engine priority: ElevenLabs first, then free fallbacks
    engines = [
        ("ElevenLabs", _try_elevenlabs),
        ("espeak",     _try_espeak),
        ("pyttsx3",    _try_pyttsx3),
        ("say",        _try_say_macos),
        ("gTTS",       _try_gtts),
    ]

    for name, fn in engines:
        try:
            logger.info(f"🎙️  Trying TTS engine: {name} ...")
            ok = fn(text, wav_path)
            if ok and _is_real_audio(wav_path):
                dur = _duration(wav_path) or estimated
                logger.info(f"✅ Voiceover created with {name}: {wav_path.name} ({dur:.1f}s)")
                return wav_path, dur
            else:
                logger.warning(f"   {name} did not produce valid audio, trying next...")
        except Exception as e:
            logger.warning(f"   {name} failed: {e}")

    logger.warning("⚠️  No TTS engine worked. Using silent audio.")
    _silent_audio(wav_path, estimated)
    return wav_path, _duration(wav_path) or estimated


# ── ENGINE 1: ElevenLabs (best quality, needs API key) ───────────────────
def _try_elevenlabs(text: str, wav_path: Path) -> bool:
    """
    Generate speech with ElevenLabs. Writes an MP3 then converts to WAV
    so the rest of the pipeline stays consistent.
    """
    if not ELEVENLABS_API_KEY:
        logger.info("   ElevenLabs key not set — skipping (set ELEVENLABS_API_KEY)")
        return False

    try:
        from elevenlabs.client import ElevenLabs
        from elevenlabs import VoiceSettings
    except ImportError:
        logger.info("   elevenlabs not installed (pip install elevenlabs) — skipping")
        return False

    client = ElevenLabs(api_key=ELEVENLABS_API_KEY)

    # Generate audio stream (returns an iterator of MP3 byte chunks)
    audio = client.text_to_speech.convert(
        voice_id=ELEVENLABS_VOICE_ID,
        text=text,
        model_id=ELEVENLABS_MODEL,
        output_format="mp3_44100_128",
        voice_settings=VoiceSettings(
            stability=0.5,            # 0-1: lower = more expressive/varied
            similarity_boost=0.75,    # 0-1: higher = closer to the chosen voice
            style=0.3,                # 0-1: style exaggeration
            use_speaker_boost=True,
        ),
    )

    mp3_path = wav_path.with_suffix(".mp3")
    with open(mp3_path, "wb") as f:
        for chunk in audio:
            if chunk:
                f.write(chunk)

    if not mp3_path.exists() or mp3_path.stat().st_size < MIN_VALID_BYTES:
        logger.warning("   ElevenLabs returned empty audio (check key/quota)")
        return False

    # Convert MP3 → WAV for pipeline consistency
    subprocess.run(
        ["ffmpeg", "-y", "-i", str(mp3_path), str(wav_path)],
        capture_output=True, text=True,
    )
    mp3_path.unlink(missing_ok=True)
    return wav_path.exists()


# ── ENGINE 2: espeak (Linux command-line, reliable, robotic) ─────────────
def _try_espeak(text: str, wav_path: Path) -> bool:
    exe = shutil.which("espeak-ng") or shutil.which("espeak")
    if not exe:
        logger.info("   espeak not installed (Linux: sudo apt install espeak)")
        return False
    cmd = [exe, "-s", "150", "-w", str(wav_path), text]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode == 0 and wav_path.exists()


# ── ENGINE 3: pyttsx3 (cross-platform offline) ────────────────────────────
def _try_pyttsx3(text: str, wav_path: Path) -> bool:
    try:
        import pyttsx3
    except ImportError:
        logger.info("   pyttsx3 not installed (pip install pyttsx3)")
        return False
    engine = pyttsx3.init()
    engine.setProperty("rate", 160)
    engine.setProperty("volume", 1.0)
    voices = engine.getProperty("voices")
    if voices:
        engine.setProperty("voice", voices[0].id)
    engine.save_to_file(text, str(wav_path))
    engine.runAndWait()
    engine.stop()
    return wav_path.exists()


# ── ENGINE 4: macOS 'say' command ────────────────────────────────────────
def _try_say_macos(text: str, wav_path: Path) -> bool:
    say = shutil.which("say")
    if not say:
        return False
    aiff = wav_path.with_suffix(".aiff")
    r = subprocess.run([say, "-o", str(aiff), text], capture_output=True, text=True)
    if r.returncode != 0 or not aiff.exists():
        return False
    subprocess.run(["ffmpeg", "-y", "-i", str(aiff), str(wav_path)],
                   capture_output=True, text=True)
    aiff.unlink(missing_ok=True)
    return wav_path.exists()


# ── ENGINE 5: gTTS (free, needs internet, no key) ────────────────────────
def _try_gtts(text: str, wav_path: Path) -> bool:
    try:
        from gtts import gTTS
    except ImportError:
        logger.info("   gTTS not installed (pip install gTTS) — optional")
        return False
    mp3 = wav_path.with_suffix(".mp3")
    tts = gTTS(text=text, lang="en")
    tts.save(str(mp3))
    subprocess.run(["ffmpeg", "-y", "-i", str(mp3), str(wav_path)],
                   capture_output=True, text=True)
    mp3.unlink(missing_ok=True)
    return wav_path.exists()


# ── HELPERS ───────────────────────────────────────────────────────────────
def _is_real_audio(wav_path: Path) -> bool:
    """Verify the WAV has actual sound, not silence or an empty file."""
    if not wav_path.exists() or wav_path.stat().st_size < MIN_VALID_BYTES:
        return False
    result = subprocess.run(
        ["ffmpeg", "-i", str(wav_path), "-af", "volumedetect", "-f", "null", "-"],
        capture_output=True, text=True,
    )
    for line in result.stderr.splitlines():
        if "mean_volume" in line:
            try:
                db = float(line.split("mean_volume:")[1].split("dB")[0].strip())
                if db < -50:
                    logger.warning(f"   Audio is effectively silent ({db} dB)")
                    return False
                return True
            except (IndexError, ValueError):
                pass
    return wav_path.stat().st_size >= MIN_VALID_BYTES


def _silent_audio(wav_path: Path, duration: float) -> Path:
    subprocess.run(
        ["ffmpeg", "-y", "-f", "lavfi",
         "-i", "anullsrc=channel_layout=stereo:sample_rate=44100",
         "-t", str(duration), str(wav_path)],
        capture_output=True, text=True,
    )
    logger.info(f"🔇 Silent audio created: {wav_path.name} ({duration:.1f}s)")
    return wav_path


def _duration(audio_path: Path) -> float | None:
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(audio_path)],
            capture_output=True, text=True,
        )
        return float(result.stdout.strip())
    except Exception:
        return None
