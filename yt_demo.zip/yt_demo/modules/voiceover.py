"""
modules/voiceover.py  (DEMO version)
─────────────────────────────────────
Generates a voiceover MP3/WAV using pyttsx3 — a FREE, OFFLINE text-to-speech
engine. No API key, no internet needed.

  - Windows: uses built-in SAPI5 voices
  - macOS:   uses built-in NSSpeechSynthesizer
  - Linux:   needs 'espeak' installed (sudo apt install espeak)

If pyttsx3 is not installed OR fails, it falls back to generating a SILENT
audio track of an estimated duration so the video still assembles.
"""

import logging
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


def generate_voiceover(text: str, output_dir: Path, use_voice: bool = True) -> tuple[Path, float]:
    """
    Convert text to speech offline.

    Args:
        text: the narration text
        output_dir: where to save the audio
        use_voice: if False, generate silent audio (faster)

    Returns:
        (audio_path, duration_seconds)
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    wav_path = output_dir / "voiceover.wav"

    # Estimate duration: average speaking rate ~150 words/min = 2.5 words/sec
    word_count = len(text.split())
    estimated_duration = max(8.0, word_count / 2.5)

    if not use_voice:
        logger.info("🔇 --no-voice flag set, generating silent audio")
        return _silent_audio(wav_path, estimated_duration), estimated_duration

    # Try pyttsx3 offline TTS
    try:
        import pyttsx3
        logger.info(f"🎙️  Generating offline voiceover ({word_count} words)...")

        engine = pyttsx3.init()
        engine.setProperty("rate", 160)      # words per minute
        engine.setProperty("volume", 1.0)

        # Pick a voice (use first available)
        voices = engine.getProperty("voices")
        if voices:
            engine.setProperty("voice", voices[0].id)

        engine.save_to_file(text, str(wav_path))
        engine.runAndWait()
        engine.stop()

        if wav_path.exists() and wav_path.stat().st_size > 1000:
            actual = _get_duration(wav_path) or estimated_duration
            logger.info(f"✅ Voiceover saved: {wav_path.name} ({actual:.1f}s)")
            return wav_path, actual
        else:
            logger.warning("pyttsx3 produced empty file, falling back to silent audio")
            return _silent_audio(wav_path, estimated_duration), estimated_duration

    except ImportError:
        logger.warning(
            "pyttsx3 not installed — using silent audio.\n"
            "   Install with: pip install pyttsx3   (Linux also needs: sudo apt install espeak)"
        )
        return _silent_audio(wav_path, estimated_duration), estimated_duration
    except Exception as e:
        logger.warning(f"TTS failed ({e}) — using silent audio instead")
        return _silent_audio(wav_path, estimated_duration), estimated_duration


def _silent_audio(wav_path: Path, duration: float) -> Path:
    """Generate a silent WAV of the given duration using FFmpeg."""
    cmd = [
        "ffmpeg", "-y",
        "-f", "lavfi",
        "-i", f"anullsrc=channel_layout=stereo:sample_rate=44100",
        "-t", str(duration),
        str(wav_path),
    ]
    subprocess.run(cmd, capture_output=True, text=True)
    logger.info(f"🔇 Silent audio created: {wav_path.name} ({duration:.1f}s)")
    return wav_path


def _get_duration(audio_path: Path) -> float | None:
    """Get audio duration via ffprobe, or None if it fails."""
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(audio_path)],
            capture_output=True, text=True,
        )
        return float(result.stdout.strip())
    except Exception:
        return None
