"""
modules/script_writer.py  (DEMO version)
─────────────────────────────────────────
Generates a simple script from a built-in template.
NO AI, NO API KEY. Just fills a topic into a fixed structure.

In the real pipeline this is replaced by an LLM call.
Here it just proves the rest of the pipeline works.

Returns a dict:
    {
      "topic": str,
      "title": str,
      "slides": [ {"heading": str, "narration": str}, ... ]
    }
The script is broken into "slides" — one chunk of narration per image.
"""


def generate_script(topic: str, num_slides: int = 5) -> dict:
    """
    Build a template script for the given topic.

    Args:
        topic: the video subject
        num_slides: how many slides/sections to create

    Returns:
        dict with title and a list of slide dicts
    """
    topic_clean = topic.strip().rstrip(".")

    # A simple, generic narration structure that works for any topic.
    # Each entry: (slide heading, narration sentence(s))
    template = [
        ("Introduction",
         f"Have you ever wondered about {topic_clean.lower()}? "
         f"It's something most people never stop to think about, but the answer is fascinating."),

        ("The Big Question",
         f"Today we're going to explore {topic_clean.lower()}. "
         f"By the end of this video, you'll see it in a completely new way."),

        ("What's Really Going On",
         f"When we look closely at {topic_clean.lower()}, "
         f"we find that there's far more beneath the surface than we expected. "
         f"The details reveal a surprising pattern."),

        ("Why It Matters",
         f"Understanding {topic_clean.lower()} isn't just interesting trivia. "
         f"It actually changes how we think about the world around us every single day."),

        ("The Takeaway",
         f"So the next time you encounter {topic_clean.lower()}, "
         f"you'll know the real story. Thanks for watching, and don't forget to subscribe for more."),

        ("Bonus Insight",
         f"Here's one final thought about {topic_clean.lower()} that very few people realise. "
         f"It connects everything we've talked about into one simple idea."),

        ("A Closer Look",
         f"Let's dig a little deeper into {topic_clean.lower()}. "
         f"The more you examine it, the more questions it raises."),
    ]

    # Take exactly num_slides entries (cycling if needed)
    slides = []
    for i in range(num_slides):
        heading, narration = template[i % len(template)]
        slides.append({"heading": heading, "narration": narration})

    # Build a simple title
    title = topic_clean if topic_clean[0].isupper() else topic_clean.capitalize()

    return {
        "topic": topic_clean,
        "title": title,
        "slides": slides,
    }


def full_narration(script: dict) -> str:
    """Join all slide narrations into one continuous text for TTS."""
    return " ".join(slide["narration"] for slide in script["slides"])
