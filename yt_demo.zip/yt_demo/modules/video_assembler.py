"""
modules/video_assembler.py  (DEMO version)
────────────────────────────────────────────
Assembles slide images + audio into an MP4 using FFmpeg.

Each slide shows for an equal share of the total audio duration.
A subtle fade between slides keeps it from looking static.

Requires: ffmpeg in PATH.
"""

import logging
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

W, H = 1920, 1080


def _run(cmd, step):
    """Run an ffmpeg command, raising on error."""
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        logger.error(f"FFmpeg failed [{step}]:\n{result.stderr[-1200:]}")
        raise RuntimeError(f"FFmpeg error at '{step}'")
    return result


def assemble_video(
    slides: list[Path],
    audio_path: Path,
    audio_duration: float,
    output_dir: Path,
    filename: str = "demo_video.mp4",
) -> Path:
    """
    Combine slides + audio into a final MP4.

    Args:
        slides: list of slide image paths (in order)
        audio_path: path to the voiceover/silent audio
        audio_duration: total audio length in seconds
        output_dir: where to save the video
        filename: output file name

    Returns:
        Path to the final MP4
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / filename

    n = len(slides)
    per_slide = max(3.0, audio_duration / n)   # seconds each slide shows

    logger.info(f"🎬 Assembling video | {n} slides × {per_slide:.1f}s | audio {audio_duration:.1f}s")

    # Build FFmpeg inputs: each image looped for per_slide seconds
    input_args = []
    for img in slides:
        input_args += ["-loop", "1", "-t", f"{per_slide:.3f}", "-i", str(img)]
    # Audio is the final input
    input_args += ["-i", str(audio_path)]

    # Build filter: scale each slide, add a gentle fade in/out, then concat
    filter_parts = []
    fade = 0.4  # seconds
    for i in range(n):
        filter_parts.append(
            f"[{i}:v]scale={W}:{H}:force_original_aspect_ratio=decrease,"
            f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1,"
            f"fade=t=in:st=0:d={fade},fade=t=out:st={per_slide - fade:.3f}:d={fade}[v{i}]"
        )
    concat_inputs = "".join(f"[v{i}]" for i in range(n))
    filter_parts.append(f"{concat_inputs}concat=n={n}:v=1:a=0[video]")
    filter_complex = "; ".join(filter_parts)

    cmd = [
        "ffmpeg", "-y",
        *input_args,
        "-filter_complex", filter_complex,
        "-map", "[video]",
        "-map", f"{n}:a",            # the audio input
        "-c:v", "libx264",
        "-preset", "medium",
        "-crf", "23",
        "-pix_fmt", "yuv420p",       # required for broad player compatibility
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",                 # stop at whichever (video/audio) ends first
        "-movflags", "+faststart",
        str(output_path),
    ]

    logger.info("⚙️  Rendering with FFmpeg (this can take 1–3 minutes)...")
    _run(cmd, "assemble")

    size_mb = output_path.stat().st_size / (1024 * 1024)
    logger.info(f"✅ Video saved: {output_path}  ({size_mb:.1f} MB)")
    return output_path
