"""
modules/slide_maker.py  (DEMO version)
───────────────────────────────────────
Generates placeholder slide images locally with Pillow.
NO Pexels, NO internet, NO API key.

Each slide is a 1920x1080 image with:
  - A gradient background (colour cycles per slide)
  - The slide heading in large bold text
  - The narration text wrapped below it
  - A slide number indicator

This proves the video assembly works. In the real pipeline these are
replaced by downloaded stock photos or AI-generated images.
"""

import logging
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

logger = logging.getLogger(__name__)

W, H = 1920, 1080

# A palette of pleasant gradient pairs (top colour, bottom colour)
GRADIENTS = [
    ((25, 35, 70),   (60, 30, 90)),    # deep blue → purple
    ((20, 60, 70),   (15, 90, 80)),    # teal → green
    ((70, 30, 50),   (110, 40, 60)),   # maroon → rose
    ((30, 45, 80),   (20, 80, 120)),   # navy → cyan
    ((60, 45, 20),   (110, 75, 25)),   # brown → gold
    ((45, 25, 65),   (80, 35, 95)),    # violet
    ((25, 55, 55),   (30, 85, 70)),    # forest
]


def _get_font(size: int, bold: bool = True):
    """Load a usable TrueType font, trying common system paths."""
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold
            else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    ]
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except (IOError, OSError):
            continue
    return ImageFont.load_default()


def _wrap(draw, text, font, max_width):
    """Word-wrap text to fit within max_width pixels."""
    words = text.split()
    lines, current = [], ""
    for word in words:
        test = (current + " " + word).strip()
        bbox = draw.textbbox((0, 0), test, font=font)
        if bbox[2] - bbox[0] <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def _gradient_bg(top, bottom):
    """Create a vertical gradient background image."""
    base = Image.new("RGB", (W, H), top)
    draw = ImageDraw.Draw(base)
    for y in range(H):
        t = y / H
        r = int(top[0] + (bottom[0] - top[0]) * t)
        g = int(top[1] + (bottom[1] - top[1]) * t)
        b = int(top[2] + (bottom[2] - top[2]) * t)
        draw.line([(0, y), (W, y)], fill=(r, g, b))
    return base


def make_slides(script: dict, output_dir: Path) -> list[Path]:
    """
    Create one image per slide in the script.

    Args:
        script: dict from script_writer with "slides" and "title"
        output_dir: where to save slide images

    Returns:
        List of image paths in order
    """
    slides_dir = output_dir / "slides"
    slides_dir.mkdir(parents=True, exist_ok=True)

    title = script["title"]
    slides = script["slides"]
    paths = []

    font_heading = _get_font(96, bold=True)
    font_body    = _get_font(52, bold=False)
    font_small   = _get_font(36, bold=True)
    font_title   = _get_font(44, bold=True)

    logger.info(f"🎨 Generating {len(slides)} slide images...")

    for i, slide in enumerate(slides):
        top, bottom = GRADIENTS[i % len(GRADIENTS)]
        img = _gradient_bg(top, bottom)
        draw = ImageDraw.Draw(img)

        margin = 140
        max_text_w = W - 2 * margin

        # ── Channel/title strip at top ──
        draw.text((margin, 70), title.upper(), font=font_title, fill=(255, 255, 255))
        draw.line([(margin, 140), (W - margin, 140)], fill=(255, 255, 255), width=2)

        # ── Heading (centred vertically-ish) ──
        heading = slide["heading"]
        heading_lines = _wrap(draw, heading, font_heading, max_text_w)
        y = 280
        for line in heading_lines:
            bbox = draw.textbbox((0, 0), line, font=font_heading)
            lw = bbox[2] - bbox[0]
            x = (W - lw) // 2
            # shadow
            draw.text((x + 3, y + 3), line, font=font_heading, fill=(0, 0, 0))
            draw.text((x, y), line, font=font_heading, fill=(255, 255, 255))
            y += 110

        # ── Body narration ──
        y += 40
        body_lines = _wrap(draw, slide["narration"], font_body, max_text_w)
        for line in body_lines:
            bbox = draw.textbbox((0, 0), line, font=font_body)
            lw = bbox[2] - bbox[0]
            x = (W - lw) // 2
            draw.text((x, y), line, font=font_body, fill=(225, 225, 235))
            y += 70

        # ── Slide number indicator (bottom right) ──
        indicator = f"{i + 1} / {len(slides)}"
        bbox = draw.textbbox((0, 0), indicator, font=font_small)
        iw = bbox[2] - bbox[0]
        draw.text((W - margin - iw, H - 110), indicator, font=font_small, fill=(255, 255, 255))

        # ── Accent bar at bottom ──
        draw.rectangle([(0, H - 12), (W, H)], fill=(255, 255, 255))

        # Save
        path = slides_dir / f"slide_{i + 1:02d}.png"
        img.save(path, "PNG")
        paths.append(path)
        logger.info(f"   ✓ slide {i + 1}: {slide['heading']}")

    logger.info(f"✅ {len(paths)} slides created")
    return paths
