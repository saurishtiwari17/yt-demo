# YouTube Video Generator — DEMO (No API Keys Needed)

This is a **local-only demo** of the video generation pipeline.
It does NOT upload anything and does NOT need any API keys or internet.

## What it does
1. Reads a topic from `topics/topics.txt`
2. Generates a simple script from a built-in template (no LLM)
3. Creates a voiceover using **pyttsx3** (free offline TTS) — or silent audio if not installed
4. Generates colourful placeholder slide images locally with **Pillow** (no Pexels)
5. Assembles images + audio into an MP4 using **FFmpeg**
6. Saves the video to the `output/` folder — that's it, no upload

## Requirements
- Python 3.10+
- FFmpeg installed and in PATH
- Python packages: `pip install Pillow pyttsx3`
  - `Pillow` — image generation (required)
  - `pyttsx3` — offline voiceover (optional; falls back to silent audio)

### Installing FFmpeg
- Ubuntu/Debian: `sudo apt install ffmpeg`
- Mac: `brew install ffmpeg`
- Windows: download from ffmpeg.org and add to PATH

### Installing pyttsx3 voice support
- Windows: works out of the box (uses SAPI5)
- Mac: works out of the box (uses NSSpeechSynthesizer)
- Linux: also install espeak → `sudo apt install espeak`

## How to run
```bash
pip install Pillow pyttsx3
python demo.py
```

Optional flags:
```bash
python demo.py --topic "Why humans fear the dark"   # use a specific topic
python demo.py --slides 6                            # number of slides
python demo.py --no-voice                            # silent video, faster
```

The finished video appears in `output/` as `demo_video.mp4`.

## Folder structure
```
yt_demo/
├── demo.py                  ← run this
├── topics/topics.txt        ← your topics, one per line
├── modules/
│   ├── script_writer.py     ← template-based script (no AI)
│   ├── voiceover.py         ← offline TTS / silent fallback
│   ├── slide_maker.py       ← Pillow placeholder images
│   └── video_assembler.py   ← FFmpeg assembly
└── output/                  ← finished video goes here
```

When you're happy with the output quality, you can swap each demo module
for the real API-powered version (LLM script, ElevenLabs voice, Pexels images).
