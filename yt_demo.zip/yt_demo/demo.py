"""
demo.py
────────
LOCAL VIDEO GENERATION DEMO — No API keys, no uploads, no internet.

Pipeline:
    topic (from topics.txt)
      → template script (no AI)
      → offline voiceover (pyttsx3, or silent fallback)
      → placeholder slides (Pillow)
      → MP4 (FFmpeg)
      → saved to output/

Usage:
    python demo.py                              # uses first topic in topics.txt
    python demo.py --topic "Custom topic here"  # use a specific topic
    python demo.py --slides 6                   # number of slides (default 5)
    python demo.py --no-voice                   # silent video (faster)
    python demo.py --list                       # show topics and exit
"""

import sys
import argparse
import logging
from pathlib import Path

# ── Paths ────────────────────────────────────────────────
BASE_DIR    = Path(__file__).resolve().parent
TOPICS_FILE = BASE_DIR / "topics" / "topics.txt"
OUTPUT_DIR  = BASE_DIR / "output"

# ── Logging ──────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(message)s",
    datefmt="%H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("demo")

# ── Imports ──────────────────────────────────────────────
from modules.script_writer   import generate_script, full_narration
from modules.voiceover       import generate_voiceover
from modules.slide_maker     import make_slides
from modules.video_assembler import assemble_video


def read_topics() -> list[str]:
    if not TOPICS_FILE.exists():
        raise FileNotFoundError(f"topics.txt not found at {TOPICS_FILE}")
    lines = [l.strip() for l in TOPICS_FILE.read_text(encoding="utf-8").splitlines()]
    return [l for l in lines if l and not l.startswith("#")]


def parse_args():
    p = argparse.ArgumentParser(description="Local video generation demo (no API keys)")
    p.add_argument("--topic", type=str, default=None, help="Specific topic to use")
    p.add_argument("--slides", type=int, default=5, help="Number of slides (default 5)")
    p.add_argument("--no-voice", action="store_true", help="Generate silent video (faster)")
    p.add_argument("--list", action="store_true", help="List topics and exit")
    return p.parse_args()


def main():
    args = parse_args()

    topics = read_topics()

    if args.list:
        print("\nTopics in topics.txt:")
        for i, t in enumerate(topics, 1):
            print(f"  {i}. {t}")
        return 0

    # Pick the topic
    topic = args.topic if args.topic else topics[0]

    logger.info("=" * 58)
    logger.info("🎬 LOCAL VIDEO GENERATION DEMO (no API keys)")
    logger.info("=" * 58)
    logger.info(f"Topic: {topic}")

    # ── Step 1: Script ───────────────────────────────────
    logger.info("\n[1/4] Building script from template...")
    script = generate_script(topic, num_slides=args.slides)
    narration = full_narration(script)
    logger.info(f"✅ Script ready: {len(script['slides'])} slides, "
                f"{len(narration.split())} words")

    # ── Step 2: Voiceover ────────────────────────────────
    logger.info("\n[2/4] Generating voiceover...")
    audio_path, duration = generate_voiceover(
        text=narration,
        output_dir=OUTPUT_DIR,
        use_voice=not args.no_voice,
    )

    # ── Step 3: Slides ───────────────────────────────────
    logger.info("\n[3/4] Generating slide images...")
    slides = make_slides(script, OUTPUT_DIR)

    # ── Step 4: Assemble ─────────────────────────────────
    logger.info("\n[4/4] Assembling final video...")
    video_path = assemble_video(
        slides=slides,
        audio_path=audio_path,
        audio_duration=duration,
        output_dir=OUTPUT_DIR,
    )

    logger.info("\n" + "=" * 58)
    logger.info("🎉 DONE!")
    logger.info(f"   Video: {video_path}")
    logger.info(f"   Length: ~{duration:.0f} seconds")
    logger.info("=" * 58)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        logger.error(f"❌ Demo failed: {type(e).__name__}: {e}")
        import traceback
        logger.error(traceback.format_exc())
        sys.exit(1)
